# SBL Refactor — AI Handoff

## Current baseline
We are on **Phase 5D — Admin architecture**.

Phase 4G completed the global Gen 9 sprite sizing/layout work. Sprite behaviour is now considered stable and should be frozen unless a real regression is found.

Phase 4H has started the Stats/replay-data refactor.

## Current architecture
```text
js/
├── auth.js
├── performance.js
├── pokemon-dex-ids.js
├── sbl-site.js
├── sbl-supabase.js
├── sbl-themes.js
└── services/
    ├── free-agency.js
    ├── league.js
    ├── pokemon.js
    ├── replays.js
    ├── rosters.js
    ├── seasons.js
    ├── stats.js        <-- NEW in Phase 4H
    └── trades.js
```

## What Phase 4H changed
`SBL.stats` is now the shared read-only aggregation layer for replay-derived Pokémon/team statistics.

Available APIs:
```js
SBL.stats.identity(name)
SBL.stats.pokemon(replays, options)
SBL.stats.pokemonProfile(species, replays, options)
SBL.stats.team(replays, teamFor)
SBL.stats.kda(row)
```

`stats.html` now uses the service for global Pokémon stats and Pokémon profile aggregation. Replay-summary form keys also use the stats identity function.

## Critical identity rule
There are three separate concepts:
1. display name
2. sprite filename
3. statistical identity

Do NOT use the sprite/display canonicalisation as the statistics grouping key.

For example, Deoxys-Attack, Deoxys-Defense and Deoxys-Speed must remain distinct in contexts where the league treats them as distinct draft entries.

## What to do next
Continue Phase 4H in small steps:
1. Audit each Stats tab.
2. Move one aggregation at a time into `js/services/stats.js`.
3. Fix KDA and replay event attribution at the data layer.
4. Verify edge cases.
5. Only after verification remove duplicate functions from `stats.html`.

## Known issue
The KDA tracker in Pokémon profile cards is known to have been wrong at some point. Do not assume the refactor fixes it automatically. Trace the calculation back to replay-derived kills/assists/deaths and fix the underlying aggregation.

## Sprite rule
DO NOT refactor the sprite system during Phase 4H. It is considered stable after Phase 4F–4G.

## Database rule
DO NOT change the existing Supabase schema during Phase 4H. The `replays` table still contains normal replay rows plus special IDs such as `__dashboard_state__`, `__rosters__`, and `__free_agency__`; `js/services/replays.js` centralizes that partitioning.

## Required delivery format
Every future refactor ZIP should include:
- the complete working project
- a phase document
- this handoff updated
- the verification checklist updated
- no instructions requiring manual file-by-file merging unless explicitly requested

---

## Phase 4H.2 STATUS

Stats/KDA stabilization is in progress. Phase 4H.2 fixes form-aware statistics identity, centralizes global Pokémon aggregation through `SBL.stats.pokemon()`, makes K/A/D in replay summaries individually auditable, and adds week/matchup context to K/A/D event lists.

### REQUIRED TEST
After installing Phase 4H.2, an administrator should use the existing **Reprocess all replays** control once. Existing parsed replay records do not automatically gain new parser attribution fields.

### Known issue to verify
KDA/damage attribution still needs real replay regression testing for Zoroark/Illusion, Terapagos form changes, multi-life switching, hazards/residuals, simultaneous events, and unusual faint causes. Do not remove the existing reprocess control.


## Current Status — Phase 4H.3
Stats restoration/repair is complete at the UI/aggregation layer. Do not reprocess replays automatically. The next work should be validation of K/A/D reconciliation and then a controlled parser audit if any stored event totals remain wrong.


## Phase 5D STATUS
Admin persistence/orchestration is centralised in `js/services/admin.js`. `admin.html` and `draft.html` retain presentation/event logic and delegate shared writes. Next recommended phase: 5E public page migration audit.
