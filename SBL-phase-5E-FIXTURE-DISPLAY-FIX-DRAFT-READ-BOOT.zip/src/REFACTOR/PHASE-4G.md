# Phase 4G — Global Sprite Layout Pass

## Status
Implemented on top of the working Phase 4F.7 build.

## Goal
The Gen 9 sprites are visually larger than the old sprites. This pass changes the shared layout layer so common Pokémon cells, cards, tables, trade chips and popups reserve enough space for the larger sprites instead of letting them clip, overlap text, stretch rows unpredictably, or cause horizontal overflow.

## What changed
- Added `css/sbl-sprites-layout.css`.
- Added shared sprite sizing tokens: XS, SM, MD, LG and XL.
- Loaded the sprite-layout stylesheet on every page.
- Main Pokémon cards/roster/draft/free-agency cells reserve the LG sprite area.
- Team/league hero cards reserve the XL area.
- Stats, speed, matchup and prep cells reserve MD space.
- Dense matrices and trade chips remain compact with explicit SM sizing.
- Popup/profile headers reserve the same LG sprite area regardless of Pokémon/form.
- Mobile reduces the large/hero sizes while preserving reserved space.
- Overflow protection prevents enlarged sprites from pushing content outside cards.

## Intentionally unchanged
- Sprite URLs and canonicalisation.
- Deoxys/form identity handling.
- Free Agency ownership logic.
- Trades, replays, seasons, rosters and database behaviour.
- No replay reparsing is required.

## Verification checklist
- [ ] Open every page and check there is no horizontal overflow.
- [ ] Check main roster cards with large Gen 9 sprites.
- [ ] Check Free Agency cards, including Deoxys forms.
- [ ] Check Draft cards.
- [ ] Check Team Analysis matchup/speed/type tables.
- [ ] Check Stats match-summary/profile cards.
- [ ] Check Season cards.
- [ ] Check Admin roster/draft/free-agency/trade cards.
- [ ] Open League Overview and Pokémon profile popups.
- [ ] Check Deoxys-Attack/Defense/Speed side by side.
- [ ] Check Terapagos and other large/irregular forms.
- [ ] Check mobile-width layout.
