# Phase 4H.3 — Stats Restoration & Repair

## Purpose
Restore the trusted Stats aggregation behaviour while preserving the newer assist data and form-aware Pokémon identity. This phase fixes UI/aggregation regressions without changing the database or forcing replay reparsing.

## Key fixes
- Global damage leaderboard explicitly sorts highest damage first.
- K/D totals use the processed replay `mons` values and no longer depend on a separate incompatible aggregation path.
- Assist totals prefer the length of `assistLog` when present, keeping the displayed number and popup feed synchronized.
- Pokémon profile aggregation uses the same shared source as the global leaderboard.
- Form-aware display names are preserved, including Deoxys forms.
- Match summary cards now aggregate every battle stint for the same Pokémon instead of replacing earlier stints with the last one. This fixes missing K/A/D, damage, and event feeds in match-summary popups.
- Franchise statistics use the same assist-count rule.

## Reprocessing
**Do not reprocess existing replays as part of installing this phase.** Existing processed replay data is consumed as-is. Reprocessing is a separate operation and should only happen after parser behaviour is explicitly verified.

## Regression checklist
- [ ] Damage leaderboard is strictly highest → lowest.
- [ ] Golden Fist kill totals equal the corresponding Pokémon profile/global kill totals.
- [ ] Match summary K/A/D totals equal the aggregated replay `mons` totals.
- [ ] Clicking K, A, or D shows every stored event for that Pokémon in scope.
- [ ] Pokémon that appeared in multiple switch-in stints retain all damage/K/A/D.
- [ ] Assist count equals the number of assist records shown.
- [ ] Death count equals the number of death records shown.
- [ ] Deoxys-Attack/Defense/Speed remain distinct.
- [ ] Terapagos forms remain distinct where stored.
- [ ] Franchise stats match global stats for the same team/Pokémon.
- [ ] No changes to sprites, roster/trade/free-agency behaviour, or database schema.
- [ ] Do not reparse until the above checks pass.
