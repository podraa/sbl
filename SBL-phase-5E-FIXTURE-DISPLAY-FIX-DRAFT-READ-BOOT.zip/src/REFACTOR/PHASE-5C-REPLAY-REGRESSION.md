# Phase 5C — Replay Regression Suite

## Purpose

Phase 5C freezes the canonical replay behavior behind regression coverage before the refactor moves into Admin architecture. The suite is organized around the five required areas:

1. **Attribution** — direct, indirect, residual, delayed, hazard, weather, and explicit-source damage attribution.
2. **Damage** — multi-hit accounting, recoil/self-damage, Substitute, direct/indirect reconciliation, and escaped Showdown HP tokens.
3. **Forms** — Illusion replacement, Zoroark/Zoroark-Hisui separation, mid-battle forme changes, and Transform.
4. **KDA** — kills, deaths, assists, simultaneous fainting, self-KOs, and forfeit/disconnect handling.
5. **Assists** — damage thresholds, item-removal attribution, duplicate suppression, and killer exclusion.

## Production regression fixture

`tests/fixtures/gen9natdexdraft-2636238237.log` remains the production regression fixture for the historical Item Removed = 0 damage issue. The fixture is asserted through `phase5a-real-replay-2636238237.test.js`.

## Known open bug

**BUG-5B-ZOROARK** remains open. Zoroark and Zoroark-Hisui can render as separate canonical rows while the underlying production replay data can still be wrong. Synthetic identity-separation tests therefore remain useful, but are explicitly not treated as proof that the production bug is fixed.

## Exit criteria

- Canonical parser is exercised without page-specific parser copies.
- All five regression categories have executable coverage.
- The real Item Removed replay passes.
- Known Zoroark failure is documented rather than hidden by a passing UI separation test.
- The full regression runner passes before Phase 5D begins.
