# Known Bugs

## BUG-5B-ZOROARK — Zoroark tracking

**Status:** Open

**Introduced/observed:** Phase 5B

**Symptoms:**
- Zoroark and Zoroark-Hisui may appear as separate Pokémon in the UI.
- Their underlying replay-derived statistics can still be incorrect.
- Damage, KDA, assists, and/or death attribution can be assigned to the wrong Zoroark identity in production replays.

**Important:** A synthetic test that produces two separate canonical rows does not constitute a fix. The real replay path must be verified.

**5C handling:** Keep this as an explicit regression target. Do not weaken the suite to make the bug disappear.

**Planned resolution:** Revisit during replay attribution/forms hardening after the 5C regression suite is established.

## BUG-5A — Item Removed zero-damage audit

**Status:** Fixed / protected by regression coverage

The escaped Showdown HP-token parsing regression is covered by the real replay fixture `2636238237`.
