# Phase 5D — Admin Architecture

## Status
Implemented.

## Scope
Centralise privileged persistence/orchestration for:
- replay loading, saving, deletion and stale-row maintenance
- shared dashboard state
- published roster persistence
- season archive/start/restore/delete lifecycle
- draft state normalisation and persistence

## Architecture
`js/services/admin.js` owns Supabase write orchestration and season/draft persistence. `admin.html` and `draft.html` retain UI rendering, prompts, validation and event handling, but delegate storage mutations to `SBL.admin`.

## Safety rules
- Existing `replays`, `__dashboard_state__`, and `__rosters__` records are preserved.
- No Supabase schema changes.
- Public read services remain separate from privileged admin writes.
- Sprite services are untouched.

## Verification
- `node --check js/services/admin.js`
- Inline JavaScript in `admin.html` and `draft.html` syntax checked.
- Archive contains the complete working project and refactor documentation.


## Stability correction
The Admin page was intentionally restored to the known-good Phase 5C implementation. The Phase 5D admin-service extraction is not active. This prevents the refactor from changing the Admin boot path while Phase 5D work continues elsewhere.
