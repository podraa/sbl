# Refactor Verification Checklist

## Phase 4H — Stats / Replay Layer

### Before testing
- [ ] Replace the whole project with the Phase 4H ZIP.
- [ ] Confirm the site still logs in normally.
- [ ] Confirm non-Stats pages still load.
- [ ] Do not reparse replays solely for this refactor.

### Stats page — core loading
- [ ] League Overview loads.
- [ ] Season/week selector works.
- [ ] Team standings load.
- [ ] Pokémon search loads and filters.
- [ ] Franchise/team stats load.
- [ ] Replay browser loads.
- [ ] Match summary popup opens.
- [ ] Pokémon profile popup opens.
- [ ] Death Causes loads.
- [ ] Luckiest loads.
- [ ] Golden Fist loads.

### Statistics correctness
- [ ] Kills match the replay.
- [ ] Assists match the replay.
- [ ] Deaths match the replay.
- [ ] Damage dealt matches the replay.
- [ ] Damage taken matches the replay.
- [ ] Games/appearances are correct.
- [ ] K/D is correct.
- [ ] KDA is correct.
- [ ] Zero-death K/D displays correctly.
- [ ] Pokémon with no games remain handled correctly where expected.

### Form / identity tests
- [ ] Deoxys-Attack remains distinct from Deoxys-Defense.
- [ ] Deoxys-Speed remains distinct from the other Deoxys forms.
- [ ] Thundurus-Incarnate and Thundurus-Therian remain distinct.
- [ ] Tornadus-Incarnate and Tornadus-Therian remain distinct.
- [ ] Landorus-Incarnate and Landorus-Therian remain distinct.
- [ ] Enamorus-Incarnate and Enamorus-Therian remain distinct.
- [ ] Terapagos forms do not collapse unexpectedly.
- [ ] Mimikyu form changes do not create duplicate stat rows unless intentionally desired.

### Replay edge cases to verify later in 4H
- [ ] Zoroark Illusion damage attribution.
- [ ] Damage from the copied Pokémon is credited correctly.
- [ ] Switching and multiple battle stints for one Pokémon.
- [ ] Terapagos form changes on switch-in.
- [ ] Terastallization.
- [ ] Mega evolution.
- [ ] Form changes that occur mid-battle.
- [ ] Multi-hit moves.
- [ ] Hazards.
- [ ] Recoil.
- [ ] Struggle.
- [ ] Self-KO.
- [ ] Weather/terrain damage.
- [ ] Status damage.
- [ ] Substitute interactions.
- [ ] Fainting from indirect damage.
- [ ] Simultaneous fainting.
- [ ] Forfeits/DCs.
- [ ] Pokémon never sent but present in team preview.

### Regression
- [ ] Roster page still works.
- [ ] Free Agency still works.
- [ ] Team Analysis still works.
- [ ] Season page still works.
- [ ] Draft still works.
- [ ] Admin still works.
- [ ] Sprites still work.
- [ ] Popup sprites still work.
- [ ] Large Gen 9 sprites still fit their cells.

## Do not remove yet
- [ ] Do not remove the embedded replay parser until the replacement service is verified.
- [ ] Do not change the database schema in Phase 4H.
- [ ] Do not change sprite logic as part of the Stats migration.


### Phase 4H.3 Stats Repair
- [ ] Damage leaderboard highest → lowest
- [ ] Golden Fist = global/profile kills
- [ ] Match summary aggregates all stints
- [ ] K/A/D popup feeds show all stored events
- [ ] Assist count = assist feed length
- [ ] Death count = death feed length
- [ ] Form-specific Pokémon remain distinct
- [ ] No replay reprocessing performed during this phase

## Phase 5C — Replay regression suite
- [x] Attribution regression coverage
- [x] Damage regression coverage
- [x] Forms regression coverage
- [x] KDA regression coverage
- [x] Assist regression coverage
- [x] Real replay 2636238237 regression coverage
- [x] Known Zoroark tracking bug explicitly documented
- [x] Canonical parser remains the single parser implementation
- [x] Full Phase 5C runner passes
