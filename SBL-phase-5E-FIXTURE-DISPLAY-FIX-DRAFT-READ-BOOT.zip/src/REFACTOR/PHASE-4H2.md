# Phase 4H.2 — Stats/KDA Repair

## Purpose
Repair the Stats page's K/A/D aggregation and audit trail after Phase 4H.1.

## Changes
- Centralized global Pokémon aggregation through `SBL.stats.pokemon()`.
- Statistics identity now preserves Pokémon forms instead of using the display/search normalizer.
- Deoxys-Attack/Defense/Speed and other forms remain separate statistical records.
- Franchise Stats matches roster entries to replay records using the form-aware statistics identity.
- Pokémon Search no longer collapses form-aware names into the base species.
- Replay-summary K/A/D values are individually clickable and open the exact credited event list.
- K/A/D audit/profile records now show week and matchup in addition to turn, cause, and replay.
- Residual status attribution survives a switch/return for the same side+form-aware Pokémon identity.
- Existing reprocess-all functionality remains available because old replay records may have been parsed under the previous identity/attribution rules.

## Important
Existing processed replays are stored parsed data. Parser/stat fixes do **not** retroactively alter those records. After installing this phase, an administrator should use **Reprocess all replays** once so historical replay records are rebuilt with the current parser.

No database schema change is required.
