# Phase 5C UI improvements

## Replay event View links
Event-level View links now include the canonical Showdown replay `?turn=N` query parameter. Showdown's replay viewer natively reads this parameter and calls `seekTurn`, so the replay opens directly at the recorded event turn.

Applied to Pokémon profile Kill, Assist, and Death event tables and the corresponding Stats audit tables.

## Pokémon Overview
The Pokémon profile Overview tab now labels the existing ratio explicitly as **Kills / Game**, calculated as `kills / games` with two decimal places.

## Luck leaderboard expansion

The canonical replay parser now scores additional probabilistic events instead of treating luck as only crits/misses/status-roll dodges: probabilistic secondary status/volatile/boost effects, flinches, confusion self-hits, and consecutive Protect/Detect-style successes are tracked with event-level audit records. Deterministic effects remain neutral.
