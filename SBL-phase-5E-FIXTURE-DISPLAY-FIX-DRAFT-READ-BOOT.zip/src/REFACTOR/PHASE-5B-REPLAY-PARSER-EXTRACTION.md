# Phase 5B — Replay Parser Extraction

## Status

**Complete.**

## Scope

The production Showdown replay parser is now owned by `js/services/replays.js`.
`admin.html`, `stats.html`, and `season.html` no longer contain their own `parseLog()` or HP/parser helper implementations.

All three pages load the shared replay service and call:

```js
SBL.replays.parseLog(json, replayId)
```

Replay move-accuracy data is likewise exposed through:

```js
SBL.replays.ensureMoveAccuracyData()
```

## Compatibility contract

The Phase 5A regression suite remains the compatibility gate. The suite now runs:

- 12 parser regressions
- 5 item-removal ledger assertions
- 21 replay regression cases
- exact replay `gen9natdexdraft-2636238237`
- parser extraction ownership check
- Zoroark/Zoroark-Hisui canonical identity regression
- Death-tab killer type-badge regression

All seven test suites pass.

## Identity/UI hardening

### Zoroark forms

`Zoroark` and `Zoroark-Hisui` are distinct canonical Stats identities. Their appearance, damage, K/D/A, assists, and death data are aggregated independently.

### Death-tab killers

Killer Pokémon in the Pokémon profile **Deaths** tab render as name-only event links. Type badges are intentionally suppressed. The same rule is applied to the inline fallback renderer.

## Architectural boundary

```text
Showdown replay JSON
        ↓
SBL.replays.parseLog()
        ↓
canonical replay record
        ↓
SBL.stats
        ↓
Stats / Admin / Season UI
```

The parser has no dependency on page-specific DOM or Supabase state.


## Post-5B regression fix: Zoroark / Illusion physical identity

The parser now keys persistent battle identity by **side + battle nickname**, not by the species shown on a switch line. This is required because Zoroark can enter under Illusion as a species that already appeared earlier in the replay. Species-based identity reused the earlier Pokémon's mon object and could move damage/KDA into Zoroark-Hisui when `|replace|` revealed the true form.

This fix is parser version 4 and is covered by a regression where a normal Zoroark deals damage, a different nicknamed Zoroark-Hisui later enters disguised as Zoroark, and the resulting damage/kills remain on the correct canonical forms.

**Important:** existing Supabase replay rows contain processed `mons` snapshots. After deploying this parser, the commissioner/admin must run **Stats → Process → Reprocess all replays** so those stored snapshots are regenerated with parser version 4.
