# Global SBL Refactor Roadmap — Current State

## Completed / substantially complete

- Shared navigation and site shell
- Global theme system
- Shared Supabase/auth utilities
- Shared Pokémon normalization and sprite service
- Shared roster service
- Shared season service
- Shared league state
- Shared Free Agency service
- Shared Trades service
- Shared Replay service
- Performance/cache layer
- Global sprite/layout system
- Stats event normalization
- Canonical Pokémon statistics aggregation
- Stats profile UI extraction
- Golden Fist UI extraction
- **Phase 5A replay regression suite and attribution hardening**
- **Phase 5B replay parser extraction, form identity hardening, and Death-tab killer cleanup**

## Current phase

### Phase 5C — Replay regression suite

Harden the canonical replay parser with a dedicated regression suite covering attribution, damage, forms, KDA, and assists. Real replay fixtures are included where a production regression has existed. The suite must distinguish parser correctness from known open bugs and must not silently mark a UI-only identity separation as a parser fix.

Phase 5B remains complete for the parser extraction and Death-tab badge cleanup, but **Zoroark/Zoroark-Hisui tracking remains an open bug**. The current tests prove canonical rows can remain separate in synthetic data; they do not prove the production replay attribution problem is fixed.

### Phase 5D — Admin architecture

**Completed.** Shared admin persistence/orchestration now lives in `js/services/admin.js`; admin and draft UIs delegate privileged writes to it.

Refactor replay ingestion, roster upload/publish, season management, draft management, and maintenance operations into shared admin services. Keep public read paths separate from privileged write paths.

### Phase 5E — Page migration audit

Audit every public page for duplicated fetching, calculations, Pokémon normalization, theme logic, navigation, modal code, and legacy CSS/JS. Migrate remaining page-specific logic onto the shared services.

### Phase 5F — Shared UI components

Finish reusable components for dropdowns, cards, tabs, modals, tables, Pokémon links/sprites, loading states, empty states, and errors.

### Phase 5G — Data integrity

Add validation and defensive handling for old/malformed replay records, roster mismatches, archived seasons, missing sprites, renamed teams, and legacy data.

### Phase 5H — Performance

Reduce duplicate Supabase reads, repeated aggregation, unnecessary DOM work, and redundant assets after the architecture is stable.

### Phase 5I — Final cleanup

Remove dead/legacy code, obsolete compatibility paths, duplicate CSS/JS, and temporary refactor artifacts. Run a full browser regression suite before release.
