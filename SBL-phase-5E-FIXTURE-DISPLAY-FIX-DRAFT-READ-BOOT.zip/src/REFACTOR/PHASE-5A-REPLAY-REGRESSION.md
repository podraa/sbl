# Phase 5A — Replay Regression & Attribution Hardening

## Status

**COMPLETE.**

The production replay parser is now covered by a deterministic regression harness that exercises the major event families called out by the refactor roadmap.

## Test architecture

Tests load the actual `parseLog()` implementation from `admin.html` through `REFACTOR/tests/load-parser.js`. The harness supplies lightweight browser stubs so parser tests can run under Node without a DOM library or Supabase connection.

The complete phase runner is:

```bash
node REFACTOR/tests/run-replay-regression.js
```

## Final result

**39 regression assertions passed across 4 suites.**

- 12 existing synthetic parser regressions
- 5 item-removal ledger invariants
- 21 broader replay regression cases
- 1 exact real-replay regression for `gen9natdexdraft-2636238237`

See `PHASE-5A-TEST-RESULTS.md` for the detailed breakdown.

## Covered event families

- Attribution / explicit source resolution
- Damage and direct/indirect buckets
- Multi-hit attacks
- Substitute/self-damage protection
- Recoil
- Entry hazards
- Status residuals
- Persistent status attribution
- Future Sight delayed attribution
- Weather damage
- Illusion replacement
- Transform
- Mid-battle form changes
- K/D/A attribution
- Assist threshold behavior
- Item-removal assists
- Duplicate-assist prevention
- Simultaneous fainting
- Self-KO outcomes
- Forfeit outcomes
- Exact replay regression

## Rule for this phase

The visible Stats UI was intentionally left alone. Parser/data-layer regressions belong in replay ingestion so reprocessed data remains consistent across every consumer.

## Exit criteria

- [x] Production parser executes under a Node regression harness.
- [x] Regression cases cover attribution, damage, forms, KDA, and assists.
- [x] Exact supplied replay remains a regression fixture.
- [x] Combined runner passes.
- [x] Existing item-removal test no longer depends on a machine-specific path.
- [x] No parallel parser implementation was introduced.

## Next phase

**Phase 5B — Replay parser extraction:** move the production `parseLog()` implementation out of `admin.html` into the shared replay-processing service while preserving this regression suite as the contract.
