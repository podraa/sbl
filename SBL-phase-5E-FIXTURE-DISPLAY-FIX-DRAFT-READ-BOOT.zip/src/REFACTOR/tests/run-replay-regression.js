'use strict';
const {spawnSync}=require('child_process');
const path=require('path');

const root=path.resolve(__dirname);
const suites=[
  'phase5a-parser-regression.js',
  'phase5a-item-removal-ledger.test.js',
  'replay-regression-suite.js',
  'phase5a-real-replay-2636238237.test.js',
  'phase5b-parser-extraction.test.js',
  'phase5b-zoroark-identity.test.js',
  'phase5b-death-killer-badges.test.js',
  'phase5c-luck-logic.test.js'
];
let failed=0;
for(const file of suites){
  console.log(`\n=== ${file} ===`);
  const result=spawnSync(process.execPath,[path.join(root,file)],{stdio:'inherit'});
  if(result.status!==0){ failed++; }
}
console.log(`\nReplay regression suite: ${failed ? 'FAIL' : 'PASS'} (${suites.length} suites)`);
process.exit(failed?1:0);
