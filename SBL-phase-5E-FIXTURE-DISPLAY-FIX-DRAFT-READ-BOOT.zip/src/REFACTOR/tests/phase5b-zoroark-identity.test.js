'use strict';
const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const path=require('path');
const root=path.resolve(__dirname,'../..');

function loadStats(){
  const service=fs.readFileSync(path.join(root,'js/services/stats.js'),'utf8');
  const pokemon=fs.readFileSync(path.join(root,'js/services/pokemon.js'),'utf8');
  const window={SBL:{}};
  const context={window,console};
  vm.createContext(context);
  vm.runInContext(pokemon,context);
  vm.runInContext(service,context);
  return window.SBL.stats;
}
const stats=loadStats();
const replayA={id:'zoroark-normal',players:{p1:'Alice',p2:'Bob'},mons:{a:{species:'Zoroark',side:'p1',appearances:1,damageDealt:37,damageTaken:20,kills:1,deaths:0,assists:0}}};
const replayB={id:'zoroark-hisui',players:{p1:'Alice',p2:'Bob'},mons:{b:{species:'Zoroark-Hisui',side:'p1',appearances:1,damageDealt:91,damageTaken:44,kills:0,deaths:1,assists:2}}};
const rows=stats.pokemon([replayA,replayB]);
const normal=rows.find(x=>x.identity==='zoroark');
const hisui=rows.find(x=>x.identity==='zoroark-hisui');
assert(normal,'Zoroark must have its own canonical row');
assert(hisui,'Zoroark-Hisui must have its own canonical row');
assert.strictEqual(normal.games,1);
assert.strictEqual(normal.dealt,37);
assert.strictEqual(normal.kills,1);
assert.strictEqual(normal.deaths,0);
assert.strictEqual(hisui.games,1);
assert.strictEqual(hisui.dealt,91);
assert.strictEqual(hisui.kills,0);
assert.strictEqual(hisui.deaths,1);
assert.notStrictEqual(normal.identity,hisui.identity);
console.log('PASS | Phase 5B Zoroark identity: Zoroark and Zoroark-Hisui remain separate canonical stat rows');
