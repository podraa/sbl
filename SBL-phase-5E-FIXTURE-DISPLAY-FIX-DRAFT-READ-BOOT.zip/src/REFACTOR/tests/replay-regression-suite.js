'use strict';
const {loadParser}=require('./load-parser');
const parseLog=loadParser();
const assert=require('assert');

function replay(body,id='regression-replay'){
  return parseLog({log:body,formatid:'gen9natdexdraft',uploadtime:1750000000000},id);
}
function mon(r,species,side){return Object.values(r.mons).find(m=>m.species===species&&m.side===side);}
function mons(r,side){return Object.values(r.mons).filter(m=>m.side===side);}
const H='|player|p1|Alice\n|player|p2|Bob\n|poke|p1|A, L50\n|poke|p1|C, L50\n|poke|p1|D, L50\n|poke|p1|Zoroark, L50\n|poke|p1|Zoroark-Hisui, L50\n|poke|p1|Terapagos, L50\n|poke|p1|Terapagos-Stellar, L50\n|poke|p2|B, L50\n';
const SW='|switch|p1a: A|A, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n';
const cases=[];
function test(name,fn){cases.push([name,fn]);}

test('Attribution: explicit [of] source wins',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|60/100|[from] move: Tackle|[of] p1a: A\n');
 assert.strictEqual(mon(r,'A','p1').damageDealt,40);
});

test('Attribution: switching target breaks stale direct-hit attribution',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|50/100|[from] move: Tackle|[of] p1a: A\n|switch|p2a: D|D, L50|100/100\n|turn|2\n|-damage|p2a: D|0/100\n|faint|p2a: D\n');
 assert.strictEqual(mon(r,'A','p1').kills,0);
});

test('Damage: multi-hit attacks sum every damage event',()=>{
 const r=replay(H+SW+'|move|p1a: A|Bullet Seed|p2a: B\n|-damage|p2a: B|80/100|[from] move: Bullet Seed|[of] p1a: A\n|-damage|p2a: B|60/100|[from] move: Bullet Seed|[of] p1a: A\n|-damage|p2a: B|40/100|[from] move: Bullet Seed|[of] p1a: A\n');
 assert.strictEqual(mon(r,'A','p1').damageDealt,60);
 assert.strictEqual(mon(r,'A','p1').directDamage,60);
});

test('Damage: Substitute damage is not credited as opposing direct damage',()=>{
 const r=replay(H+SW+'|move|p1a: A|Substitute|p1a: A\n|-damage|p1a: A|75/100|[from] substitute\n');
 assert.strictEqual(mon(r,'A','p1').damageDealt,0);
});

test('Damage: recoil is self damage and not credited to opponent',()=>{
 const r=replay(H+SW+'|move|p1a: A|Flare Blitz|p2a: B\n|-damage|p2a: B|60/100|[from] move: Flare Blitz|[of] p1a: A\n|-damage|p1a: A|80/100|[from] recoil\n');
 assert.strictEqual(mon(r,'A','p1').damageDealt,40);
 assert.strictEqual(mon(r,'B','p2').damageTaken,40);
});

test('Forms: Illusion replace merges battle identity',()=>{
 const r=replay(H+'|switch|p1a: Zoroark|Zoroark, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: Zoroark|Tackle|p2a: B\n|-damage|p2a: B|50/100|[from] move: Tackle|[of] p1a: Zoroark\n|replace|p1a: Zoroark|Zoroark-Hisui, L50\n|move|p1a: Zoroark-Hisui|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: Zoroark-Hisui\n|faint|p2a: B\n');
 assert.strictEqual(mons(r,'p1').length,1);
 assert.strictEqual(mon(r,'Zoroark-Hisui','p1')?.damageDealt,100);
});

test('Forms: Illusion disguise does not steal an existing species identity',()=>{
 const r=replay(H+'|switch|p1a: Zed|Zoroark, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: Zed|Tackle|p2a: B\n|-damage|p2a: B|50/100|[from] move: Tackle|[of] p1a: Zed\n|switch|p1a: C|C, L50|100/100\n|switch|p1a: Hisu|Zoroark, L50|100/100\n|replace|p1a: Hisu|Zoroark-Hisui, L50\n|move|p1a: Hisu|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: Hisu\n|faint|p2a: B\n');
 assert.strictEqual(mon(r,'Zoroark','p1')?.damageDealt,50);
 assert.strictEqual(mon(r,'Zoroark-Hisui','p1')?.damageDealt,50);
 assert.strictEqual(mon(r,'Zoroark','p1')?.kills,0);
 assert.strictEqual(mon(r,'Zoroark-Hisui','p1')?.kills,1);
});

test('Forms: mid-battle formechange preserves identity',()=>{
 const r=replay(H+'|switch|p1a: Terapagos|Terapagos, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|-formechange|p1a: Terapagos|Terapagos-Stellar\n|move|p1a: Terapagos-Stellar|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: Terapagos-Stellar\n|faint|p2a: B\n');
 assert.strictEqual(mons(r,'p1').length,1);
 assert.strictEqual(mon(r,'Terapagos-Stellar','p1').kills,1);
});

test('KDA: final damaging attacker gets kill, prior contributor gets assist',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|40/100|[from] move: Tackle|[of] p1a: A\n|switch|p1a: C|C, L50|100/100\n|move|p1a: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: C\n|faint|p2a: B\n');
 assert.strictEqual(mon(r,'C','p1').kills,1);
 assert.strictEqual(mon(r,'A','p1').assists,1);
 assert.strictEqual(mon(r,'B','p2').deaths,1);
});

test('KDA: killer never receives its own assist',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: A\n|faint|p2a: B\n');
 assert.strictEqual(mon(r,'A','p1').kills,1);
 assert.strictEqual(mon(r,'A','p1').assists,0);
});

test('Assists: below threshold plus real KO gives no damage assist',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|80/100|[from] move: Tackle|[of] p1a: A\n|move|p1a: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: C\n|faint|p2a: B\n');
 assert.strictEqual(mon(r,'A','p1').assists,0);
});

test('Assists: qualifying damage gives exactly one assist',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|40/100|[from] move: Tackle|[of] p1a: A\n|switch|p1a: C|C, L50|100/100\n|move|p1a: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: C\n|faint|p2a: B\n');
 assert.strictEqual(mon(r,'A','p1').assists,1);
 assert.strictEqual(mon(r,'A','p1').assistLog.length,1);
});

test('Assists: item removal + qualifying damage merges into one audit entry',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|40/100|[from] move: Tackle|[of] p1a: A\n|-enditem|p2a: B|Leftovers|[of] p1a: A\n|switch|p1a: C|C, L50|100/100\n|move|p1a: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: C\n|faint|p2a: B\n');
 const a=mon(r,'A','p1'); assert.strictEqual(a.assists,1); assert.strictEqual(a.assistLog.length,1); assert.strictEqual(a.assistLog[0].damage,60);
});

test('Assists: killer excluded from item-removal contribution',()=>{
 const r=replay(H+SW+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: A\n|-enditem|p2a: B|Leftovers|[of] p1a: A\n|faint|p2a: B\n');
 assert.strictEqual(mon(r,'A','p1').assists,0);
});

test('Attribution: Stealth Rock is indirect and setter-owned',()=>{
 const r=replay(H+SW+'|move|p1a: A|Stealth Rock|p2a: B\n|-damage|p2a: B|90/100|[from] Stealth Rock\n');
 const a=mon(r,'A','p1'); assert.strictEqual(a.indirectDamage,10); assert.strictEqual(a.directDamage,0);
});

test('Attribution: persistent status damage remains tied to inflictor',()=>{
 const r=replay(H+SW+'|move|p1a: A|Toxic|p2a: B\n|-status|p2a: B|tox\n|switch|p2a: B|B, L50|100/100\n|turn|2\n|-damage|p2a: B|90/100|[from] psn\n');
 assert.strictEqual(mon(r,'A','p1').damageDealt,10);
});

test('Attribution: Future Sight delayed hit stays with original setter',()=>{
 const r=replay(H+SW+'|move|p1a: A|Future Sight|p2a: B\n|switch|p1a: C|C, L50|100/100\n|-end|p2a: B|move: Future Sight\n|-damage|p2a: B|50/100\n');
 assert.strictEqual(mon(r,'A','p1').damageDealt,50);
 assert.strictEqual(mon(r,'C','p1').damageDealt,0);
});

test('Attribution: weather chip is indirect and setter-owned',()=>{
 const r=replay(H+SW+'|move|p1a: A|Sunny Day|p1a: A\n|-weather|RainDance|[of] p1a: A\n|-weather|Sandstorm|[of] p1a: A\n|-damage|p2a: B|90/100|[from] Sandstorm\n');
 const a=mon(r,'A','p1'); assert.strictEqual(a.indirectDamage,10); assert.strictEqual(a.directDamage,0);
});

test('KDA: simultaneous fainting produces distinct deaths without fake kills',()=>{
 const r=replay(H+'|switch|p1a: A|A, L50|1/100\n|switch|p2a: B|B, L50|1/100\n|turn|1\n|-damage|p1a: A|0/100|[from] psn\n|-damage|p2a: B|0/100|[from] psn\n|faint|p1a: A\n|faint|p2a: B\n');
 assert.strictEqual(mon(r,'A','p1').deaths,1); assert.strictEqual(mon(r,'B','p2').deaths,1); assert.strictEqual(mon(r,'A','p1').kills,0); assert.strictEqual(mon(r,'B','p2').kills,0);
});

test('KDA: self-KO does not award opposing kill/assist',()=>{
 const r=replay(H+SW+'|move|p1a: A|Explosion|p2a: B\n|-damage|p2a: B|0/100|[from] move: Explosion|[of] p1a: A\n|-damage|p1a: A|0/100|[from] move: Explosion|[of] p1a: A\n|faint|p2a: B\n|faint|p1a: A\n');
 assert.strictEqual(mon(r,'A','p1').kills,1); assert.strictEqual(mon(r,'A','p1').assists,0); assert.strictEqual(mon(r,'B','p2').deaths,1);
});

test('Outcomes: forfeit/disconnect log without fabricating a death',()=>{
 const r=replay(H+SW+'|turn|1\n|win|Alice\n|raw|Alice forfeited.\n');
 assert.strictEqual(mon(r,'A','p1').deaths,0); assert.strictEqual(mon(r,'B','p2').deaths,0);
});

test('Forms: Transform does not create a second source identity',()=>{
 const r=replay(H+'|switch|p1a: A|A, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: A|Transform|p2a: B\n|-transform|p1a: A|p2a: B\n|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: A\n|faint|p2a: B\n');
 assert.strictEqual(mons(r,'p1').length,1);
 assert.strictEqual(mon(r,'A','p1').kills,1);
});

let failed=0;
for(const [name,fn] of cases){try{fn();console.log('PASS | '+name)}catch(e){failed++;console.log('FAIL | '+name+' | '+e.message)}}
console.log(`\n${cases.length-failed}/${cases.length} regression cases passed`);
process.exit(failed?1:0);
