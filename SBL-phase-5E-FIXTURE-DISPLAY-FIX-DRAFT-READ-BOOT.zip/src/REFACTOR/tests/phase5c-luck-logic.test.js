'use strict';
const assert=require('assert');
const {loadParser}=require('./load-parser');
const parser=loadParser();

// Inject the same shape produced by moves.json, but keep the test deterministic/offline.
parser.__setMoveDataForTests?.({
  thunderwave:{accuracy:90,statusChances:{par:100},secondaryEffects:[]},
  rockslide:{accuracy:90,statusChances:{},secondaryEffects:[{kind:'flinch',value:'flinch',chance:30}]},
  airslash:{accuracy:95,statusChances:{},secondaryEffects:[{kind:'flinch',value:'flinch',chance:30}]},
  confusemove:{accuracy:100,statusChances:{},secondaryEffects:[{kind:'volatileStatus',value:'confusion',chance:50}]},
  tackle:{accuracy:100,statusChances:{},secondaryEffects:[]},
  fireblast:{accuracy:85,statusChances:{brn:30},secondaryEffects:[]}
});

const log=`|player|p1|Alice
|player|p2|Bob
|switch|p1a: AliceMon|Togekiss, L50|100/100
|switch|p2a: BobMon|Gengar, L50|100/100
|turn|1
|move|p1a: AliceMon|Rock Slide|p2a: BobMon
|-flinch|p2a: BobMon
|turn|2
|move|p1a: AliceMon|Rock Slide|p2a: BobMon
|-damage|p2a: BobMon|90/100
|turn|3
|move|p1a: AliceMon|Confuse Move|p2a: BobMon
|-confusion|p2a: BobMon
|-damage|p2a: BobMon|80/100|[from] confusion
|turn|4
|move|p1a: AliceMon|Protect|p1a: AliceMon
|-activate|p1a: AliceMon|move: Protect
|turn|5
|move|p1a: AliceMon|Protect|p1a: AliceMon
|-activate|p1a: AliceMon|move: Protect
`;

const parsed=parser({log},'phase5c-luck-logic');
const p1=parsed.luck.p1;
assert(p1.flinches===1,'flinch proc should be counted');
assert(p1.flinchLuck>0,'successful 30% flinch should be lucky');
assert(p1.confusionLuck>0,'causing confusion self-hit should be favorable to the inflictor');
assert(p1.confusionSelfHits===0,'confusion self-hit belongs to the confused target, not the inflictor');
assert(p1.protectSuccesses===1,'only the second consecutive Protect success is luck-scored');
assert(p1.protectLuck>1,'second consecutive Protect should carry positive luck');
assert(parsed.luck.p2.confusionSelfHits===1,'confused target self-hit should be recorded');
assert(parsed.luck.p2.confusionLuck<0,'confusion self-hit should be unlucky for the confused target');

const statusLog=`|player|p1|A\n|player|p2|B\n|switch|p1a: A|Charizard, L50|100/100\n|switch|p2a: B|Scizor, L50|100/100\n|turn|1\n|move|p1a: A|Fire Blast|p2a: B\n|-status|p2a: B|brn\n|turn|2\n|switch|p2a: C|Scizor, L50|100/100\n|move|p1a: A|Fire Blast|p2a: C\n|turn|3\n`;
const statusParsed=parser({log:statusLog},'phase5c-status');
assert(statusParsed.luck.p1.secondaryLuck>0,'probabilistic status proc should be lucky for the inflictor');
assert(statusParsed.luck.p2.secondaryLuck<0,'probabilistic status proc should be unlucky for the target');
assert(statusParsed.luck.p2.statusDodgeLuck>0,'avoiding a secondary status roll should be lucky for the target');

console.log('PASS | Phase 5C luck logic: secondary procs, flinches, confusion and consecutive Protect are scored');
