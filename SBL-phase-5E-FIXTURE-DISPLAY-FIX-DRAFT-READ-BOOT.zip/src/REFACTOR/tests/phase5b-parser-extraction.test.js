'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const {loadParser}=require('./load-parser');
const root=path.resolve(__dirname,'../..');

const parser=loadParser();
const fixture=`|player|p1|Alice\n|player|p2|Bob\n|switch|p1a: Zoroark|Zoroark, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: Zoroark|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: Zoroark\n|faint|p2a: B\n`;
const parsed=parser({log:fixture},'phase5b-parser-extraction');
assert(parsed && parsed.mons && Object.values(parsed.mons).some(m=>m.species==='Zoroark'));

for(const file of ['admin.html','stats.html','season.html']){
  const text=fs.readFileSync(path.join(root,file),'utf8');
  assert(!/function\s+parseLog\s*\(/.test(text),`${file} must not own a parseLog implementation`);
  assert(text.includes('js/services/replays.js'),`${file} must load the shared replay service`);
}
const service=fs.readFileSync(path.join(root,'js/services/replays.js'),'utf8');
assert(service.includes('SBL.replays.parseLog=parseLog'),'shared replay service must expose parseLog');
assert(service.includes('function parseLog(json, replayId)'),'canonical parser must live in replay service');
console.log('PASS | Phase 5B parser extraction: shared parser is the sole page-independent implementation');
