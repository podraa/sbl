'use strict';
const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const path=require('path');
const root=path.resolve(__dirname,'../..');
const source=fs.readFileSync(path.join(root,'js/stats/profile-ui.js'),'utf8');
const window={SBLStatsUI:{}};
const context={window,console};
vm.createContext(context);
vm.runInContext(source,context,{filename:'profile-ui.js'});
const render=window.SBLStatsUI.renderPokemonProfile;
assert.strictEqual(typeof render,'function');
const deps={
  pokemonProfileData:()=>({species:'Victim',identity:'victim',games:1,kills:0,assists:0,deaths:1,dealt:10,taken:100,directDamage:10,indirectDamage:0,switches:0,leads:0,coaches:new Set(['Team']),weeksBrought:new Map(),killLog:[],assistLog:[],deathLog:[{turn:7,killer:'Zoroark-Hisui',cause:'Moongeist Beam',replayId:'test-replay'}]}),
  escapeHtml:s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),
  pokemonLink:(species,inner)=>`<span class="pokemon-click">${inner}</span>`,
  spriteImg:(species)=>`<img alt="${species}">`,
  displayCause:x=>x,
  replayContext:()=>({week:'Week 1',matchup:'A vs B'})
};
const html=render('Victim','ALL',deps);
const deathStart=html.indexOf('data-profile-section="deaths"');
assert(deathStart>=0,'Deaths tab must render');
const death=html.slice(deathStart);
assert(death.includes('Zoroark-Hisui'),'killer must be present in death tab');
assert(!death.includes('type-badge'),'death-tab killer must not render type badges');
assert(!death.includes('type-badges'),'death-tab killer must not render type badge containers');
console.log('PASS | Phase 5B death killer UI: killer entries render without type badges');
