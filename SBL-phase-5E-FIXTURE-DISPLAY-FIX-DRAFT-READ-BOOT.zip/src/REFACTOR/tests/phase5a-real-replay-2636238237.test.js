'use strict';

const fs = require('fs');
const path = require('path');
const {loadParser} = require('./load-parser');

const parseLog = loadParser();
const fixture = fs.readFileSync(path.join(__dirname, 'fixtures/gen9natdexdraft-2636238237.log'), 'utf8');
const replay = parseLog({
  log: fixture,
  formatid: 'gen9natdexdraft',
  uploadtime: 1782017253
}, 'gen9natdexdraft-2636238237');

function mon(species, side){
  return Object.values(replay.mons).find(m=>m.species===species && m.side===side);
}
function assert(condition, message){
  if(!condition) throw new Error(message);
}

const tinkaton = mon('Tinkaton','p2');
const muk = mon('Muk-Alola','p1');

assert(tinkaton, 'Tinkaton must be parsed');
assert(muk, 'Muk-Alola must be parsed');

// This replay is the original regression case: HP tokens in the downloaded
// Showdown HTML are escaped (`85\\/100`). Before the fix, parseHP() returned 0
// for those tokens, so every damage contribution became 0 and the Stats/Audit
// view showed Item Removed with 0 damage.
assert(tinkaton.kills === 1, 'Tinkaton should receive its Ribombee KO');
assert(tinkaton.assists === 0, 'the killer must not also receive an assist');

const mukAssists = muk.assistLog.filter(x=>x.replayId==='gen9natdexdraft-2636238237');
assert(mukAssists.length === 2, `Muk-Alola should have 2 assists, got ${mukAssists.length}`);
assert(mukAssists.every(x=>x.damage > 0), 'item-removal assists must retain non-zero prior damage');
assert(mukAssists.some(x=>x.cause==='item removal + damage' && x.damage===95 && x.percent===95), 'Walking Wake item removal must retain 95 damage');
assert(mukAssists.some(x=>x.cause==='item removal + damage' && x.damage===73 && x.percent===73), 'Lycanroc-Dusk item removal must retain 73 damage');
assert(new Set(mukAssists.map(x=>`${x.turn}|${x.victim}`)).size===2, 'item removal + damage must not create duplicate audit rows');

console.log('PASS | real replay 2636238237 item-removal audit regression');
