#!/usr/bin/env node
'use strict';

const {spawnSync}=require('child_process');
const path=require('path');

const root=__dirname;
const groups=[
  {name:'Attribution', files:['phase5a-parser-regression.js','replay-regression-suite.js']},
  {name:'Damage', files:['phase5a-parser-regression.js','replay-regression-suite.js','phase5a-real-replay-2636238237.test.js']},
  {name:'Forms', files:['replay-regression-suite.js','phase5b-zoroark-identity.test.js']},
  {name:'KDA', files:['replay-regression-suite.js']},
  {name:'Assists', files:['phase5a-item-removal-ledger.test.js','replay-regression-suite.js','phase5a-real-replay-2636238237.test.js']}
];

// The category runner intentionally executes the canonical suites rather than
// copying parser logic into five different test implementations. This keeps
// Phase 5C focused on behavior while the parser remains single-source.
let failed=0;
const seen=new Set();
for(const group of groups){
  console.log(`\n=== 5C ${group.name} ===`);
  for(const file of group.files){
    if(seen.has(file)) continue;
    seen.add(file);
    const result=spawnSync(process.execPath,[path.join(root,file)],{stdio:'inherit'});
    if(result.status!==0) failed++;
  }
}

console.log(`\nPhase 5C Replay Regression: ${failed ? 'FAIL' : 'PASS'}`);
process.exit(failed?1:0);
