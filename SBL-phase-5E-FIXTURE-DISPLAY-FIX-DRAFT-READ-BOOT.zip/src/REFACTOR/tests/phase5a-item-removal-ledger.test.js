const assert = require('assert');

// Mirrors the rewritten production rule: item removal stores identity only;
// damage is reconstructed from every matching damage-contributor stint.
function canonical(name){
  return String(name||'').trim().toLowerCase().replace(/[-_]+/g,' ').replace(/\s+/g,' ');
}
function itemRemovalAssist(itemEntry, contributions, victimHp, killer){
  const sourceSide=String(itemEntry.side||'');
  const sourceSpecies=canonical(itemEntry.species||'');
  if(sourceSide===String(itemEntry.victimSide||'') || itemEntry.stats===killer) return null;
  let damage=0;
  for(const c of Object.values(contributions||{})){
    if(!c?.stats) continue;
    if(String(c.stats.side||'')!==sourceSide) continue;
    if(canonical(c.stats.species)!==sourceSpecies) continue;
    damage += Number(c.damage)||0;
  }
  const percent=victimHp>0 ? damage/victimHp*100 : 0;
  return {damage,percent,reason:percent>50?'item removal + damage':'item removal'};
}

// Damage can be split across multiple battle stints/IDs. The item removal event
// must never replace that damage with zero.
{
  const result=itemRemovalAssist(
    {side:'p1',species:'Garchomp',victimSide:'p2'},
    {
      a:{stats:{id:'a',side:'p1',species:'Garchomp'},damage:25},
      b:{stats:{id:'b',side:'p1',species:'Garchomp'},damage:20},
      c:{stats:{id:'c',side:'p1',species:'Garchomp'},damage:10},
      d:{stats:{id:'d',side:'p1',species:'Landorus-Therian'},damage:99}
    },
    100,
    null
  );
  assert.ok(Math.abs(result.damage-55)<1e-9);
  assert.ok(Math.abs(result.percent-55)<1e-9);
  assert.strictEqual(result.reason,'item removal + damage');
}

// Under threshold: still display damage, but reason remains Item Removed.
{
  const result=itemRemovalAssist(
    {side:'p1',species:'Garchomp',victimSide:'p2'},
    {a:{stats:{side:'p1',species:'Garchomp'},damage:30}},
    100,
    null
  );
  assert.strictEqual(result.damage,30);
  assert.strictEqual(result.percent,30);
  assert.strictEqual(result.reason,'item removal');
}

// Exact 50% is intentionally still Item Removed because the requested rule is
// "over 50%" rather than "50% or more".
{
  const result=itemRemovalAssist(
    {side:'p1',species:'Garchomp',victimSide:'p2'},
    {a:{stats:{side:'p1',species:'Garchomp'},damage:50}},
    100,
    null
  );
  assert.strictEqual(result.damage,50);
  assert.strictEqual(result.percent,50);
  assert.strictEqual(result.reason,'item removal');
}

// Damage after item removal is also retained because the ledger is read at faint.
{
  const result=itemRemovalAssist(
    {side:'p1',species:'Garchomp',victimSide:'p2'},
    {a:{stats:{side:'p1',species:'Garchomp'},damage:30}},
    100,
    null
  );
  assert.strictEqual(result.damage,30);
}

// Verify the production files contain the new identity-only + summed-ledger path.
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'../..');
for(const file of ['js/services/replays.js']){
  const text=fs.readFileSync(path.join(root,file),'utf8');
  assert(text.includes('damage from every matching damage-contributor entry'));
  assert(text.includes("const candidateKey = `${sourceSide}|${normName(sourceSpecies)}`"));
}
console.log('Phase 5A Item Removal ledger tests: 5/5 passed');
