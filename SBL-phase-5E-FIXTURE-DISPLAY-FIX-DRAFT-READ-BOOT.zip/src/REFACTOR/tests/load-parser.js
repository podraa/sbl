'use strict';

// Phase 5B: load the canonical replay parser service directly. No page-specific
// parser extraction is used here; tests execute the same service shipped to the app.
const fs = require('fs');
const vm = require('vm');
const path = require('path');

function loadParser(){
  const servicePath = path.resolve(__dirname, '../../js/services/replays.js');
  const source = fs.readFileSync(servicePath, 'utf8');
  const window = {};
  window.SBL = {
    pokemon:{
      displayName:x=>String(x??'').trim(),
      displayNameWithForm:x=>String(x??'').trim()
    }
  };
  const context = {
    window,
    console,
    fetch:async()=>({ok:false,status:404}),
    AbortController,
    setTimeout,
    clearTimeout
  };
  vm.createContext(context);
  vm.runInContext(source, context, {filename:servicePath});
  if(typeof window.SBL?.replays?.parseLog !== 'function') throw new Error('Canonical replay parser service was not exposed');
  const parseLog = window.SBL.replays.parseLog;
  parseLog.__setMoveDataForTests = window.SBL.replays.__setMoveDataForTests;
  return parseLog;
}

module.exports = {loadParser};
