// Load the real parseLog from the Phase 5A admin.html, then exercise it with
// synthetic Showdown logs. This avoids rewriting parser logic in the test.
const {loadParser}=require('./load-parser');
const parseLog=loadParser();
function replay(log){ return parseLog({log,formatid:'gen9natdexdraft',uploadtime:1750000000000},'test-replay'); }
function mon(r, species, side){ return Object.values(r.mons).find(m=>m.species===species && m.side===side); }
function assert(cond,msg){ if(!cond) throw new Error(msg); }
const results=[];
function test(name,fn){ try{fn();results.push(['PASS',name]);}catch(e){results.push(['FAIL',name,e.message]);} }

const base='|player|p1|Alice\n|player|p2|Bob\n|poke|p1|A, L50\n|poke|p1|C, L50\n|poke|p2|B, L50\n|switch|p1a: A|A, L50|100/100\n|switch|p1b: C|C, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n';

test('damage without faint does not award assist',()=>{
 const r=replay(base+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|40/100|[from] move: Tackle|[of] p1a: A\n');
 const a=mon(r,'A','p1'); assert(a.damageDealt===60,'A damage should be 60'); assert(a.assists===0,'A must have 0 assists');
});

test('damage + killer faint awards one assist',()=>{
 const r=replay(base+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|40/100|[from] move: Tackle|[of] p1a: A\n|move|p1b: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1b: C\n|faint|p2a: B\n');
 const a=mon(r,'A','p1'), c=mon(r,'C','p1'), b=mon(r,'B','p2');
 assert(a.assists===1,'A should have 1 assist'); assert(c.kills===1,'C should have 1 kill'); assert(b.deaths===1,'B should have 1 death'); assert(a.assistLog[0].damage===60,'assist should retain 60 damage');
});

test('item removal assist retains prior damage',()=>{
 const r=replay(base+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|70/100|[from] move: Tackle|[of] p1a: A\n|-enditem|p2a: B|Leftovers|[of] p1a: A\n|move|p1b: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1b: C\n|faint|p2a: B\n');
 const a=mon(r,'A','p1'); assert(a.assists===1,'A should have item-removal assist'); assert(a.assistLog[0].cause==='item removal','cause should be item removal'); assert(a.assistLog[0].damage===30,'assist should retain 30 prior damage');
});


test('item removal under 50 percent still records damage',()=>{
 const r=replay(base+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|70/100|[from] move: Tackle|[of] p1a: A\n|-enditem|p2a: B|Leftovers|[of] p1a: A\n|move|p1b: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1b: C\n|faint|p2a: B\n');
 const a=mon(r,'A','p1'); assert(a.assistLog[0].damage===30,'under-threshold item removal must still show damage'); assert(a.assistLog[0].percent===30,'under-threshold item removal must retain percent'); assert(a.assistLog[0].cause==='item removal','under-threshold reason should be item removal');
});

test('item removal over 50 percent records damage and uses combined reason',()=>{
 const r=replay(base+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|40/100|[from] move: Tackle|[of] p1a: A\n|-enditem|p2a: B|Leftovers|[of] p1a: A\n|move|p1b: C|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1b: C\n|faint|p2a: B\n');
 const a=mon(r,'A','p1'); assert(a.assists===1,'item removal + qualifying damage must be one assist, not two'); assert(a.assistLog.length===1,'item removal + qualifying damage must produce one audit entry'); assert(a.assistLog[0].damage===60,'over-threshold item removal must retain damage'); assert(a.assistLog[0].percent===60,'over-threshold item removal must retain percent'); assert(a.assistLog[0].cause==='item removal + damage','over-threshold reason should be combined');
});

test('escaped replay HP tokens preserve damage and item-removal attribution',()=>{
 const r=replay(base+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|70\\/100|[from] move: Tackle|[of] p1a: A\n|-enditem|p2a: B|Leftovers|[from] move: Tackle|[of] p1a: A\n|move|p1b: C|Tackle|p2a: B\n|-damage|p2a: B|0\\/100|[from] move: Tackle|[of] p1b: C\n|faint|p2a: B\n');
 const a=mon(r,'A','p1'); assert(a.damageDealt===30,'escaped HP token should preserve 30 damage'); assert(a.assists===1,'escaped HP token should preserve item-removal assist'); assert(a.assistLog[0].damage===30,'escaped HP token should preserve item-removal damage');
});

test('direct and indirect damage buckets reconcile',()=>{
 const r=replay(base+'|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|70/100|[from] move: Tackle|[of] p1a: A\n|move|p1a: A|Stealth Rock|p2a: B\n|-damage|p2a: B|60/100|[from] Stealth Rock\n');
 const a=mon(r,'A','p1'); assert(a.directDamage===30,'direct damage should be 30'); assert(a.indirectDamage===10,'indirect damage should be 10'); assert(a.damageDealt===40,'total should be 40');
});

test('Illusion replace preserves same mon stats',()=>{
 const r=replay('|player|p1|Alice\n|player|p2|Bob\n|switch|p1a: Zoroark|Zoroark, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: Zoroark|Tackle|p2a: B\n|-damage|p2a: B|50/100|[from] move: Tackle|[of] p1a: Zoroark\n|replace|p1a: Zoroark|Zoroark-Hisui, L50\n|move|p1a: Zoroark-Hisui|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: Zoroark-Hisui\n|faint|p2a: B\n');
 const zs=Object.values(r.mons).filter(m=>m.side==='p1'); assert(zs.length===1,'Illusion replacement should preserve one battle identity'); assert(zs[0].damageDealt===100,'damage should remain on same identity');
});

test('mid-battle forme change preserves same mon stats',()=>{
 const r=replay('|player|p1|Alice\n|player|p2|Bob\n|switch|p1a: Terapagos|Terapagos, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: Terapagos|Tackle|p2a: B\n|-damage|p2a: B|50/100|[from] move: Tackle|[of] p1a: Terapagos\n|-formechange|p1a: Terapagos|Terapagos-Stellar\n|move|p1a: Terapagos-Stellar|Tackle|p2a: B\n|-damage|p2a: B|0/100|[from] move: Tackle|[of] p1a: Terapagos-Stellar\n|faint|p2a: B\n');
 const ts=Object.values(r.mons).filter(m=>m.side==='p1'); assert(ts.length===1,'forme change should preserve one battle identity'); assert(ts[0].damageDealt===100,'damage should remain on same identity');
});

test('hazard damage is indirect and credited to setter',()=>{
 const r=replay('|player|p1|Alice\n|player|p2|Bob\n|switch|p1a: A|A, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: A|Stealth Rock|p2a: B\n|-damage|p2a: B|90/100|[from] Stealth Rock\n');
 const a=mon(r,'A','p1'); assert(a.indirectDamage===10,'hazard damage should be indirect'); assert(a.directDamage===0,'hazard should not be direct');
});

test('status residual damage is credited to status inflictor',()=>{
 const r=replay('|player|p1|Alice\n|player|p2|Bob\n|switch|p1a: A|A, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: A|Toxic|p2a: B\n|-status|p2a: B|tox\n|turn|2\n|-damage|p2a: B|90/100|[from] psn\n');
 const a=mon(r,'A','p1'); assert(a.indirectDamage===10,'status residual should be indirect'); assert(a.damageDealt===10,'status damage should count toward dealt');
});

test('switching does not transfer prior attacker credit to new occupant',()=>{
 const r=replay('|player|p1|Alice\n|player|p2|Bob\n|switch|p1a: A|A, L50|100/100\n|switch|p2a: B|B, L50|100/100\n|turn|1\n|move|p1a: A|Tackle|p2a: B\n|-damage|p2a: B|50/100|[from] move: Tackle|[of] p1a: A\n|switch|p2a: D|D, L50|100/100\n|turn|2\n|-damage|p2a: D|0/100\n|faint|p2a: D\n');
 const a=mon(r,'A','p1'); assert(a.kills===0,'A should not inherit kill credit after target switches');
});

for(const [s,n,e] of results) console.log(s+' | '+n+(e?' | '+e:''));
const failed=results.filter(x=>x[0]==='FAIL'); console.log(`\n${results.length-failed.length}/${results.length} tests passed`); process.exit(failed.length?1:0);
