# SBL Refactor — Phase 4H: Stats / Replay Data Layer

## Status
Phase 4H.1 is implemented as a **stabilization + shared aggregation layer**. The existing replay parser and database schema were intentionally left unchanged.

## What changed
- Added `js/services/stats.js` as the shared read-only statistics aggregation layer.
- `globalPokemonStats()` now consumes `SBL.stats.pokemon()`.
- Pokémon profile aggregation now consumes `SBL.stats.pokemonProfile()`.
- Replay-summary roster keys now preserve form identity instead of using the old hyphen-collapsing `normName()` key.
- Added shared `SBL.stats.kda()` for future KDA consumers.
- Added shared team aggregation API for future migration.
- Removed the duplicate trailing `sbl-site.js` load from `stats.html`.
- No database changes.
- No replay reparsing required.
- Replay parser remains embedded in `stats.html` for now; moving it is a later, higher-risk step.

## Important identity rule
Stats identity is deliberately separate from sprite identity/display identity.

Examples that must remain distinct in replay-derived stats:
- Deoxys-Attack
- Deoxys-Defense
- Deoxys-Speed
- Thundurus-Incarnate
- Thundurus-Therian
- Terapagos-Terastal
- Terapagos-Stellar

Do not use `SBL.pokemon.displayName()` as a stats grouping key when form identity matters.

## Known issue / next work
The Stats page still contains legacy UI and replay-parser logic. Do not assume this phase has completed the Stats migration. The next Stats pass should:
1. Audit every visible Stats tab against the shared aggregation service.
2. Move replay-derived calculations out of the HTML incrementally.
3. Fix and verify KDA using raw replay event attribution.
4. Verify damage, kill, assist and death attribution, including Illusion, switching, transformations, multi-hit moves, hazards, recoil, self-KO and form changes.
5. Only then remove duplicated aggregation functions.
