# SBL Refactor

The shared service foundation and Stats architecture are in place.

## Current phase

**Phase 5D — Admin architecture**

Phase 5A (Replay Regression & Attribution Hardening) is complete. Its regression suite is retained as the compatibility contract for parser extraction.

Run the complete Phase 5A regression suite from the project root with:

```bash
node REFACTOR/tests/run-replay-regression.js
```

See:

- `GLOBAL-ROADMAP.md`
- `PHASE-5A-REPLAY-REGRESSION.md`
- `PHASE-5A-TEST-RESULTS.md`


Phase 5D adds `js/services/admin.js` for shared privileged persistence and season/draft lifecycle operations.
