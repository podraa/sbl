# Phase 5A Replay Regression — Final Test Results

## Result

**PASS — 39 regression assertions across 4 suites.**

All suites execute the production replay parser from `admin.html`; the regression suite does not maintain a second parser implementation.

### Suite breakdown

| Suite | Result | Coverage |
|---|---:|---|
| `phase5a-parser-regression.js` | **12/12** | Existing parser regression coverage |
| `phase5a-item-removal-ledger.test.js` | **5/5** | Item-removal ledger invariants |
| `replay-regression-suite.js` | **21/21** | Attribution, damage, forms, KDA, assists, outcomes |
| `phase5a-real-replay-2636238237.test.js` | **PASS** | Exact supplied replay regression |

The combined runner is:

`REFACTOR/tests/run-replay-regression.js`

Run from the project root:

```bash
node REFACTOR/tests/run-replay-regression.js
```

## Regression coverage

The 21-case suite covers:

1. Explicit `[of]` attribution.
2. Stale attacker attribution after switching.
3. Multi-hit damage accumulation.
4. Substitute/self-damage protection.
5. Recoil protection.
6. Illusion replacement.
7. Mid-battle forme changes.
8. Final-hit KO attribution and prior damage assist.
9. Killer exclusion from assists.
10. Below-threshold damage with a real KO.
11. Qualifying damage assist.
12. Item removal + damage merge without duplicate audit rows.
13. Killer exclusion from item-removal credit.
14. Entry-hazard attribution.
15. Persistent status attribution across a return to the field.
16. Future Sight delayed attribution after the setter switches.
17. Weather chip attribution.
18. Simultaneous fainting.
19. Self-KO / Explosion-style outcomes.
20. Forfeit outcome without fabricated deaths.
21. Transform identity preservation.

## Exact replay regression

`gen9natdexdraft-2636238237` is retained as a real-world fixture and regression test.

The exact fixture is:

`REFACTOR/tests/fixtures/gen9natdexdraft-2636238237.log`

The test verifies the known item-removal audit behavior, including non-zero damage attribution and duplicate-row prevention.

## Scope discipline

No Stats UI rewrite was made for this phase. The goal was to establish a reusable regression contract around the existing replay/stat ingestion behavior.

No new production parser implementation was introduced in the test suite.

## Phase completion

Phase 5A is complete. The next planned phase is **Phase 5B — Replay parser extraction**.
