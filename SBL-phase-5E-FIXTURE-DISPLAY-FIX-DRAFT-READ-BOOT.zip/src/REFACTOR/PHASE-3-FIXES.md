# Phase 3 — Follow-up fixes

This build keeps the Phase 3 architecture and fixes the issues found during validation.

## Fixed
- Golden Fist renderer now resolves its content mount correctly after extraction into `js/stats/golden-fist-ui.js`.
- Pokémon profile tab renderer remains delegated through the Stats UI module and profile rendering is defensive against incomplete replay records.
- Damage Leaderboard controls are compact and left-aligned: Scope and Damage Type sit together.
- Public Damage Leaderboard CSV export button removed.
- Public Golden Fist CSV export button removed; exports should remain an admin concern.
- Item-removal assist records retain any victim-specific damage contribution already accumulated by the assisting Pokémon.

## Intentionally unchanged
- Season page.
- Replay parser rules except the item-removal assist display fix.
- Existing statistics definitions and profile tabs.
