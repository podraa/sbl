/* SBL STATS SERVICE — Phase 4H
 *
 * Read-only aggregation layer for processed replay records. The existing
 * replay parser remains untouched; this service only consumes its output.
 * UI pages should use this service instead of rebuilding KDA/damage logic.
 */
(function(){
  'use strict';
  window.SBL=window.SBL||{};
  const SBL=window.SBL;

  function rawIdentity(name){
    let id=String(name??'').trim().toLowerCase()
      .replace(/[’']/g,'').replace(/[♀]/g,'-f').replace(/[♂]/g,'-m')
      .replace(/[.:]/g,'').replace(/_/g,'-').replace(/\s+/g,'-')
      .replace(/-+/g,'-').replace(/^-|-$/g,'');
    id=id.replace(/-(forme|form|style)$/,'');
    // Keep Incarnate distinct in statistics. It is a base sprite filename in
    // Showdown, but it is still a distinct league/replay form.
    const typo={scovilalian:'scovillain',scovillian:'scovillain',scovilion:'scovillain'};
    return typo[id]||id;
  }

  function identity(name){ return rawIdentity(name); }
  function display(name){
    if(SBL.pokemon?.displayNameWithForm) return SBL.pokemon.displayNameWithForm(name);
    return String(name??'').trim();
  }

  function addNumber(obj,key,value){ obj[key]=(Number(obj[key])||0)+(Number(value)||0); }

  function empty(species){
    return {species, identity:identity(species), dealt:0,taken:0,directDamage:0,indirectDamage:0,kills:0,deaths:0,assists:0,switches:0,leads:0,games:0,appearances:0,
      killLog:[],deathLog:[],assistLog:[],coaches:new Set(),replays:new Set()};
  }

  function pokemon(replays, options={}){
    const out=new Map();
    const includeForms=options.includeForms!==false;
    for(const replay of Array.isArray(replays)?replays:[]){
      for(const mon of Object.values(replay?.mons||{})){
        if(!mon?.species) continue;
        const key=includeForms ? identity(mon.species) : identity(display(mon.species));
        if(!key) continue;
        let row=out.get(key);
        if(!row){ row=empty(display(mon.species)); out.set(key,row); }
        // Keep the first observed form-aware display name. This prevents the
        // Deoxys forms from all becoming simply "Deoxys" in the stats layer.
        if(includeForms) row.species=display(mon.species);
        const totalDamage = Number(mon.damageDealt)||0;
        const directDamage = Number(mon.directDamage)||0;
        const indirectDamage = Number(mon.indirectDamage)||0;
        const isLegacy = Number(replay.parserVersion||0) < 3;
        addNumber(row,'dealt',isLegacy ? totalDamage : (directDamage + indirectDamage));
        addNumber(row,'taken',mon.damageTaken);
        addNumber(row,'directDamage',isLegacy ? totalDamage : directDamage);
        addNumber(row,'indirectDamage',isLegacy ? 0 : indirectDamage);
        addNumber(row,'switches',mon.switches);
        addNumber(row,'leads',mon.leads);
        addNumber(row,'kills',mon.kills);
        addNumber(row,'deaths',mon.deaths);
        addNumber(row,'assists',Array.isArray(mon.assistLog) ? mon.assistLog.length : mon.assists);
        addNumber(row,'games',mon.appearances);
        addNumber(row,'appearances',mon.appearances);
        if(replay.id) row.replays.add(replay.id);
        if(typeof options.teamFor==='function'){
          const team=options.teamFor(replay.players?.[mon.side]);
          if(team) row.coaches.add(team);
        }
        if(Array.isArray(mon.killLog)) row.killLog.push(...mon.killLog);
        if(Array.isArray(mon.deathLog)) row.deathLog.push(...mon.deathLog);
        if(Array.isArray(mon.assistLog)) row.assistLog.push(...mon.assistLog);
      }
    }
    return [...out.values()].map(x=>({...x, games:Number(x.games)||0, coaches:new Set(x.coaches)}))
      .sort((a,b)=>Number(b.dealt||0)-Number(a.dealt||0) || Number(b.kills||0)-Number(a.kills||0) || String(a.species).localeCompare(String(b.species)));
  }

  function pokemonProfile(species,replays,options={}){
    const target=identity(species);
    const rows=[];
    const coaches=new Set();
    const weeksBrought=new Map();
    for(const replay of Array.isArray(replays)?replays:[]){
      let brought=false;
      for(const mon of Object.values(replay?.mons||{})){
        if(!mon?.species || identity(mon.species)!==target) continue;
        brought=true;
        const team = typeof options.teamFor==='function' ? options.teamFor(replay.players?.[mon.side]) : '';
        if(team) coaches.add(team);
        rows.push({replay,mon});
        break;
      }
      if(brought){
        const week=String(replay.week||'');
        if(week) weeksBrought.set(week,(weeksBrought.get(week)||0)+1);
      }
    }

    const agg=empty(display(species));
    agg.coaches=new Set(coaches);
    agg.weeksBrought=weeksBrought;

    const normalizeLog = (entry, replay, fallbackType) => {
      const x = entry && typeof entry === 'object' ? entry : {};
      return {
        ...x,
        replayId: String(x.replayId || x.replay || x.id || replay?.id || ''),
        replayDate: Number(x.replayDate || replay?.uploadtime || replay?.processedAt || 0) || 0,
        turn: Number(x.turn || x.turnNumber || 0) || 0,
        victim: x.victim == null ? '' : String(x.victim),
        killer: x.killer == null ? '' : String(x.killer),
        cause: x.cause == null ? '' : String(x.cause),
        damage: Number(x.damage || 0) || 0,
        percent: Number(x.percent || x.share || 0) || 0,
        type: x.type || fallbackType
      };
    };

    for(const {replay,mon} of rows){
      const totalDamage = Number(mon.damageDealt)||0;
      const directDamage = Number(mon.directDamage)||0;
      const indirectDamage = Number(mon.indirectDamage)||0;
      const isLegacy = Number(replay.parserVersion||0) < 3;
      addNumber(agg,'dealt',isLegacy ? totalDamage : (directDamage + indirectDamage));
      addNumber(agg,'taken',mon.damageTaken);
      addNumber(agg,'directDamage',isLegacy ? totalDamage : directDamage);
      addNumber(agg,'indirectDamage',isLegacy ? 0 : indirectDamage);
      addNumber(agg,'switches',mon.switches);
      addNumber(agg,'leads',mon.leads);
      addNumber(agg,'kills',mon.kills);
      addNumber(agg,'deaths',mon.deaths);
      addNumber(agg,'assists',Array.isArray(mon.assistLog) ? mon.assistLog.length : mon.assists);
      addNumber(agg,'games',Number(mon.appearances)||1);

      if(Array.isArray(mon.killLog)){
        for(const entry of mon.killLog) agg.killLog.push(normalizeLog(entry,replay,'kill'));
      }
      if(Array.isArray(mon.deathLog)){
        for(const entry of mon.deathLog) agg.deathLog.push(normalizeLog(entry,replay,'death'));
      }
      if(Array.isArray(mon.assistLog)){
        for(const entry of mon.assistLog) agg.assistLog.push(normalizeLog(entry,replay,'assist'));
      }
    }
    return agg;
  }

  function team(replays,teamFor,weekFilter){
    const out=new Map();
    for(const replay of Array.isArray(replays)?replays:[]){
      for(const side of ['p1','p2']){
        const teamName=typeof teamFor==='function'?teamFor(replay.players?.[side]):'';
        if(!teamName) continue;
        const key=String(teamName).trim().toLowerCase();
        if(!out.has(key)) out.set(key,{team:teamName,games:0,wins:0,losses:0,kills:0,deaths:0,dealt:0,taken:0,players:new Set()});
        const row=out.get(key); row.games++; if(replay.players?.[side]) row.players.add(replay.players[side]);
        const result=replay.results?.[side] || (replay.winner && String(replay.winner).toLowerCase()===String(replay.players?.[side]||'').toLowerCase()?'W':(replay.winner?'L':null));
        if(result==='W') row.wins++; else if(result==='L') row.losses++;
        for(const mon of Object.values(replay.mons||{})) if(mon?.side===side){ addNumber(row,'kills',mon.kills); addNumber(row,'deaths',mon.deaths); addNumber(row,'dealt',mon.damageDealt); addNumber(row,'taken',mon.damageTaken); }
      }
    }
    return [...out.values()];
  }

  function kda(row){
    const kills=Number(row?.kills)||0, deaths=Number(row?.deaths)||0, assists=Number(row?.assists)||0;
    return {kills,deaths,assists,ratio:deaths?((kills+assists)/deaths):((kills+assists)?Infinity:0),kd:deaths?(kills/deaths):((kills)?Infinity:0)};
  }

  SBL.stats={identity,pokemon,pokemonProfile,team,kda};
})();
