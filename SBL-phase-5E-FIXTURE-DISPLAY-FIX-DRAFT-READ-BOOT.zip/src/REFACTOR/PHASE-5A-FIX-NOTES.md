# Phase 5A follow-up fix

This build fixes the replay-to-Stats/Audit path exposed by replay `gen9natdexdraft-2636238237`.

## Root cause

The downloaded Pokémon Showdown replay HTML stores HP tokens with escaped slashes, for example `85\/100`. The parser was passing those strings directly to `parseHP()` and `parseMaxHP()`. Because the token contained a slash, `parseHP()` tried `Number("85\\")`, which became `NaN` and then `0`.

That made the battle-state HP baseline zero, so subsequent damage deltas were calculated as zero. Item-removal assists therefore reached Stats/Audit with `damage: 0` and `percent: 0` even when the Pokémon had previously dealt real damage.

## Production fixes

- `admin.html`, `season.html`, and `stats.html` now normalize escaped replay slashes (`\\/` → `/`) before parsing HP tokens.
- `parseMaxHP()` uses the same normalization so assist-threshold denominators remain correct.
- Item-removal assists and ordinary qualifying damage assists now use the same stable side + canonical species identity when building candidates.
- When the same Pokémon both qualifies through damage and removes the victim's item, the events are merged into one assist audit row. The reason is `item removal + damage` when the contribution is over 50%; otherwise it remains `item removal`.
- Item-removal damage is still reconstructed from the canonical victim damage ledger, summing matching contributor stints rather than trusting the transient `-enditem` event.

## Regression coverage

- Added an escaped-HP synthetic parser regression.
- Added the exact supplied replay fixture `gen9natdexdraft-2636238237.log` and a deterministic regression test for it.
- The exact replay now produces non-zero item-removal contributions for the affected Muk-Alola assists (95 and 73 damage) and no duplicate audit rows.
